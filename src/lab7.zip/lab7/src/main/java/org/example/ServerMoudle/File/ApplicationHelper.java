package org.example.ServerMoudle.File;
/*
public class ApplicationHelper {
    private static String login;

    public static String getLogin() {
        return login;
    }

    public static void setLogin(String login) {
        ApplicationHelper.login = login;
    }
}
 */
