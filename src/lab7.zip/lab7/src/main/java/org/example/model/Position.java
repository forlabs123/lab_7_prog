package org.example.model;

public enum Position {
    DIRECTOR,
    HEAD_OF_DIVISION,
    BAKER,
    COOK,
    CLEANER;
}