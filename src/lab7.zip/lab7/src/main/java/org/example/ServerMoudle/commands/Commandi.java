package org.example.ServerMoudle.commands;

public interface Commandi {
    public void execute(String [] args);
}
