package org.example.ServerMoudle.commands;//package org.example.ServerMoudle.commands;
//
//import org.example.ServerMoudle.File.Collection;
//
///**
// * Write the collection to the file
// */
//public class Save extends Command{
//    private Collection collection;
//
//
//    public Save(Collection collection) {
//        this.collection = collection;
//    }
//    /**
//     * Write the collection to the file
//     */
//    @Override
//    public void execute(String[] args){
//        collection.save();
//        ManagerResult.write("операция успешно выполнена");
//    }
//}

