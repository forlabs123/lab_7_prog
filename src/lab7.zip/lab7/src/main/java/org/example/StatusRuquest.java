package org.example;

public enum StatusRuquest {
    OK,
    ERROR,
    EXIT
}
