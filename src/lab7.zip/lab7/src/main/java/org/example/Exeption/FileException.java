package org.example.Exeption;

public class FileException extends Exception{
    public FileException() {
    }

    public FileException(String message) {
        super(message);
    }
}
