package org.example.DataBase;

public class test {
    public static void main(String[] args) {
        Repository repository = new Repository();
        repository.createConnection();
    }
}
